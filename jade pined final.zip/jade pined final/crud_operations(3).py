from pymongo import MongoClient

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        # Connection Variables
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 33227
        DB = 'AAC'
        COL = 'animals'

        # Initialize MongoClient Connection
        self.client = MongoClient(f'mongodb://{username}:{password}@{HOST}:{PORT}')
        self.database = self.client[DB]
        self.collection = self.database[COL]

    # Create method to insert a document
    def create(self, data):
        try:
            if data is not None:
                result = self.collection.insert_one(data)  # Insert data into MongoDB
                return result.acknowledged  # Return True if successful
            else:
                raise ValueError("Empty data cannot be inserted")
        except Exception as e:
            print(f"An error occurred while inserting data: {e}")
            return False

    # Read method to query documents
    def read(self, query):
        try:
            if query is not None:
                documents = self.collection.find(query)  # Find matching documents
                return [doc for doc in documents]  # Return as a list
            else:
                raise ValueError("Query cannot be empty")
        except Exception as e:
            print(f"An error occurred while reading data: {e}")
            return []

    # Update method to modify documents
    def update(self, query, update_data):
        try:
            if query and update_data:
                result = self.collection.update_many(query, {"$set": update_data})  # Update matching documents
                return result.modified_count  # Return the number of modified documents
            else:
                raise ValueError("Query and update data cannot be empty")
        except Exception as e:
            print(f"An error occurred while updating data: {e}")
            return 0

    # Delete method to remove documents
    def delete(self, query):
        try:
            if query is not None:
                result = self.collection.delete_many(query)  # Delete matching documents
                return result.deleted_count  # Return the number of deleted documents
            else:
                raise ValueError("Query cannot be empty")
        except Exception as e:
            print(f"An error occurred while deleting data: {e}")
            return 0


